<?php
require_once __DIR__ . '/api/auth.php';
require_once __DIR__ . '/api/db.php';
require_login();
$u = current_user();
?>
<!doctype html>
<html lang="it">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Dashboard — HairShake</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
<nav>
  <a href="index.html">Home</a>
  <a href="/api/logout.php">Logout</a>
</nav>

<h1>Dashboard</h1>
<div class="card">
  <b><?php echo htmlspecialchars($u['name']); ?></b><br>
  <small>Ruolo: <?php echo htmlspecialchars($u['role']); ?></small>
</div>

<?php if ($u['role']==='hairdresser'): ?>
  <div class="grid">
    <div class="card">
      <h3>Servizi</h3>
      <form action="/api/add_service.php" method="POST">
        <input name="title" placeholder="Es. Taglio donna" required>
        <input name="price_chf" placeholder="Prezzo CHF" required>
        <input name="duration_min" placeholder="Durata (min)" required>
        <button style="margin-top:10px">Aggiungi</button>
      </form>
    </div>

    <div class="card">
      <h3>Disponibilità</h3>
      <form action="/api/add_availability.php" method="POST">
        <label>Inizio (YYYY-MM-DD HH:MM)</label>
        <input name="start_at" required placeholder="2026-01-28 09:00">
        <label style="margin-top:10px">Fine</label>
        <input name="end_at" required placeholder="2026-01-28 17:00">
        <button style="margin-top:10px">Aggiungi</button>
      </form>
    </div>
  </div>

  <div class="card">
    <h3>Le tue prenotazioni</h3>
    <?php
      $stmt = db()->prepare("SELECT b.id,b.start_at,b.status,s.title,u.name AS client_name
                             FROM bookings b
                             JOIN services s ON s.id=b.service_id
                             JOIN users u ON u.id=b.client_id
                             WHERE b.hairdresser_id=? ORDER BY b.start_at DESC LIMIT 50");
      $stmt->bind_param("i", $u['id']);
      $stmt->execute();
      $r = $stmt->get_result();
      while($row=$r->fetch_assoc()){
        echo "<div>#" . (int)$row['id'] . " — " . htmlspecialchars($row['title']) . " — " . htmlspecialchars($row['client_name']) . " — " . htmlspecialchars($row['start_at']) . " — <b>" . htmlspecialchars($row['status']) . "</b> — <a href='messages.php?booking_id=".(int)$row['id']."'>Chat</a></div>";
      }
    ?>
  </div>
<?php else: ?>
  <div class="card">
    <h3>Le tue prenotazioni</h3>
    <?php
      $stmt = db()->prepare("SELECT b.id,b.start_at,b.status,s.title,u.name AS hairdresser_name
                             FROM bookings b
                             JOIN services s ON s.id=b.service_id
                             JOIN users u ON u.id=b.hairdresser_id
                             WHERE b.client_id=? ORDER BY b.start_at DESC LIMIT 50");
      $stmt->bind_param("i", $u['id']);
      $stmt->execute();
      $r = $stmt->get_result();
      while($row=$r->fetch_assoc()){
        echo "<div>#".(int)$row['id']." — ".htmlspecialchars($row['title'])." — ".htmlspecialchars($row['hairdresser_name'])." — ".htmlspecialchars($row['start_at'])." — <b>".htmlspecialchars($row['status'])."</b> — <a href='messages.php?booking_id=".(int)$row['id']."'>Chat</a>";
if($row['status']==='pending'){
  echo " <form style='display:inline' action='/api/pay_create_intent.php' method='POST'>
        <input type='hidden' name='booking_id' value='".(int)$row['id']."'>
        <button class='btn primary' type='submit'>Crea pagamento (Stripe)</button>
      </form>";
}
echo "</div>";
      }
    ?>
  </div>
<?php endif; ?>

</body>
</html>
