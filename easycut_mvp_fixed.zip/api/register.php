<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/smtp_send.php';

if (empty($_POST['accept'])) die("MUST_ACCEPT");

$role  = $_POST['role'] ?? 'client';
$name  = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$city  = trim($_POST['city'] ?? '');
$pass  = $_POST['password'] ?? '';

if (!$name || !$email || !$pass) die("MISSING_FIELDS");

$hash  = password_hash($pass, PASSWORD_DEFAULT);
$token = bin2hex(random_bytes(32));

$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'www.easycut.ch';
$verifyLink = $scheme . '://' . $host . '/api/verify.php?token=' . $token;

$stmt = db()->prepare("INSERT INTO users (role,name,email,password_hash,phone,city,verify_token,email_verified_at)
                       VALUES (?,?,?,?,?,?,?,NULL)");

try {
  $stmt->execute([$role,$name,$email,$hash,$phone,$city,$token]);

  // ===== SMTP INFOMANIAK =====
  $SMTP_HOST = "mail.infomaniak.com";
  $SMTP_PORT = 587;               // STARTTLS
  $SMTP_USER = "info@easycut.ch";
  $SMTP_PASS = "Fantasia181007"; //
  // ==========================

  $subject = "Conferma registrazione — HairShake";
  $message = "Ciao $name,\n\nConferma la registrazione cliccando qui:\n$verifyLink\n\nSe non sei stato tu, ignora questa email.\n";

  $sent = smtp_send_tls($SMTP_HOST,$SMTP_PORT,$SMTP_USER,$SMTP_PASS,$SMTP_USER,"HairShake",$email,$subject,$message);

  if ($sent !== true) {
    // se SMTP fallisce, NON blocchiamo: ti mostriamo il link (così non resti bloccato)
    echo "EMAIL_NON_INVIATA: $sent<br><br>LINK CONFERMA (TEST): <a href='$verifyLink'>$verifyLink</a>";
    exit;
  }

  header("Location: ../register.html?ok=1");
  exit;

} catch (mysqli_sql_exception $e) {
  if ((int)$e->getCode() === 1062) {
    header("Location: ../register.html?exists=1");
    exit;
  }
  throw $e;
}
