<?php
// CONFIGURAZIONE: inserisci qui i dati del tuo database Infomaniak
define('DB_HOST', 'YOUR_DB_HOST');
define('DB_NAME', 'YOUR_DB_NAME');
define('DB_USER', 'YOUR_DB_USER');
define('DB_PASS', 'YOUR_DB_PASSWORD');

// URL del sito (usato per link email)
define('SITE_URL', 'https://www.easycut.ch');

// Email sender (facoltativo). Se non usi SMTP, lascia vuoto e userà mail()
define('SMTP_HOST', '');
define('SMTP_PORT', 587);
define('SMTP_USER', '');
define('SMTP_PASS', '');
define('SMTP_FROM', 'noreply@easycut.ch');

// Stripe (facoltativo per MVP pagamento). Metti le tue chiavi quando attivi pagamenti
define('STRIPE_SECRET', '');
define('STRIPE_WEBHOOK_SECRET', '');
