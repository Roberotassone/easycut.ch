<?php
require_once __DIR__ . '/db.php';

$city = trim($_GET['city'] ?? '');
$like = '%' . $city . '%';

$stmt = db()->prepare("SELECT id,name,city FROM users WHERE role='hairdresser' AND (city LIKE ? OR ?='%%') ORDER BY id DESC LIMIT 100");
$stmt->bind_param("ss",$like,$like);
$stmt->execute();
$r = $stmt->get_result();

echo "<!doctype html><html lang='it'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>";
echo "<link rel='stylesheet' href='..//styles.css'><title>Risultati — HairShake</title></head><body>";

$logo = <svg width=\"28\" height=\"28\" viewBox=\"0 0 64 64\" aria-hidden=\"true\">  <defs>    <linearGradient id=\"g1\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\">      <stop offset=\"0\" stop-color=\"var(--red)\"/><stop offset=\"1\" stop-color=\"var(--cyan)\"/>    </linearGradient>  </defs>  <path d=\"M40 10c-3 0-6 3-6 6 0 3 3 6 6 6 3 0 6-3 6-6 0-3-3-6-6-6Z\" fill=\"none\" stroke=\"var(--red)\" stroke-width=\"4\"/>  <path d=\"M24 10c-3 0-6 3-6 6 0 3 3 6 6 6 3 0 6-3 6-6 0-3-3-6-6-6Z\" fill=\"none\" stroke=\"var(--cyan)\" stroke-width=\"4\"/>  <path d=\"M28 20 54 44\" stroke=\"url(#g1)\" stroke-width=\"5\" stroke-linecap=\"round\"/>  <path d=\"M36 20 10 44\" stroke=\"url(#g1)\" stroke-width=\"5\" stroke-linecap=\"round\"/>  <path d=\"M30 28 34 28\" stroke=\"rgba(26,20,32,.35)\" stroke-width=\"4\" stroke-linecap=\"round\"/></svg>;

echo "<div class='nav'><div class='nav-inner'><div class='brand'>".$logo." HairShake</div><div class='navlinks'><a class='btn ghost' href='..//index.html'>Home</a><a class='btn secondary' href='..//register.html'>Iscriviti</a><a class='btn primary' href='..//login.html'>Accedi</a></div></div></div>";

echo "<div class='container' style='max-width:900px'>";
echo "<div class='card'><div class='section-title'>Risultati</div><div class='small'>Città: <b>".htmlspecialchars($city ?: 'tutte')."</b></div></div>";
echo "<div class='list'>";
$any=false;
while($u=$r->fetch_assoc()){
  $any=true;
  echo "<div class='item'><a href='..//profile.php?id=".(int)$u['id']."'><b>".htmlspecialchars($u['name'])."</b></a><br><span class='small'>".htmlspecialchars($u['city'] ?? '')."</span></div>";
}
if(!$any){
  echo "<div class='item'><span class='small'>Nessun risultato. Prova un’altra città.</span></div>";
}
echo "</div></div></body></html>";
