<?php
require_once __DIR__ . '/auth.php';
header('Content-Type: application/json');
$u = current_user();
if(!$u){ http_response_code(401); echo json_encode(null); exit; }
echo json_encode($u);
