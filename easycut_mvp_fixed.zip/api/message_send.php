<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/db.php';
require_login();
$u = current_user();

$booking_id = (int)($_POST['booking_id'] ?? 0);
$body = trim($_POST['body'] ?? '');
if(!$booking_id || !$body){ http_response_code(400); exit('BAD_INPUT'); }

$stmt = db()->prepare("SELECT client_id,hairdresser_id FROM bookings WHERE id=? AND (client_id=? OR hairdresser_id=?)");
$stmt->bind_param("iii",$booking_id,$u['id'],$u['id']);
$stmt->execute();
$b = $stmt->get_result()->fetch_assoc();
if(!$b){ http_response_code(404); exit('NOT_FOUND'); }

$recipient = ($u['id']==$b['client_id']) ? $b['hairdresser_id'] : $b['client_id'];

$ins = db()->prepare("INSERT INTO messages (booking_id,sender_id,recipient_id,body) VALUES (?,?,?,?)");
$ins->bind_param("iiis",$booking_id,$u['id'],$recipient,$body);
$ins->execute();

header('Location: /public/messages.php?booking_id='.$booking_id);
