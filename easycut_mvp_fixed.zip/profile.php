<?php
require_once __DIR__ . '/api/db.php';
$id = (int)($_GET['id'] ?? 0);

$stmt = db()->prepare("SELECT id,name,city,bio,photo_url FROM users WHERE id=? AND role='hairdresser'");
$stmt->bind_param("i",$id);
$stmt->execute();
$u = $stmt->get_result()->fetch_assoc();
if(!$u){ http_response_code(404); exit('NOT_FOUND'); }
?>
<!doctype html>
<html lang="it">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?php echo htmlspecialchars($u['name']); ?> — HairShake</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
<nav>
  <a href="index.html">Home</a>
  <a href="login.html">Login</a>
  <a href="register.html">Registrati</a>
</nav>

<div class="card">
  <h1 style="margin:0"><?php echo htmlspecialchars($u['name']); ?></h1>
  <small><?php echo htmlspecialchars($u['city'] ?? ''); ?></small>
  <?php if(!empty($u['bio'])): ?><p><?php echo nl2br(htmlspecialchars($u['bio'])); ?></p><?php endif; ?>
</div>

<h3>Servizi</h3>
<div class="grid">
<?php
$s = db()->prepare("SELECT id,title,price_chf,duration_min,description FROM services WHERE hairdresser_id=? AND active=1 ORDER BY id DESC");
$s->bind_param("i",$id);
$s->execute();
$r = $s->get_result();
while($row=$r->fetch_assoc()){
  echo "<div class='card'><b>".htmlspecialchars($row['title'])."</b><br><small>CHF ".htmlspecialchars($row['price_chf'])." • ".(int)$row['duration_min']." min</small>";
  if(!empty($row['description'])) echo "<p><small>".htmlspecialchars($row['description'])."</small></p>";
  echo "<a href='book.php?service_id=".(int)$row['id']."'>Prenota</a></div>";
}
?>
</div>

<h3>Recensioni</h3>
<div class="card">
<?php
$rv = db()->prepare("SELECT r.rating,r.comment,r.created_at,u.name AS client_name
                     FROM reviews r JOIN users u ON u.id=r.client_id
                     WHERE r.hairdresser_id=? ORDER BY r.created_at DESC LIMIT 20");
$rv->bind_param("i",$id);
$rv->execute();
$rr = $rv->get_result();
if($rr->num_rows===0) echo "<small>Nessuna recensione ancora.</small>";
while($row=$rr->fetch_assoc()){
  echo "<div><b>".(int)$row['rating']."/5</b> — ".htmlspecialchars($row['client_name'])." <small>(" . htmlspecialchars($row['created_at']) . ")</small><br>".htmlspecialchars($row['comment'] ?? '')."</div><hr>";
}
?>
</div>
</body>
</html>
