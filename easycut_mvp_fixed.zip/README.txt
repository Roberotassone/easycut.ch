EASYCUT MVP (PHP) - Deploy su Infomaniak

1) Carica TUTTO il contenuto di questa cartella nella root del tuo sito:
   /easycut/app/Http

2) Modifica api/config.php con i dati DB.

3) Importa db/database.sql nel tuo database.

4) Apri:
   https://www.easycut.ch/
