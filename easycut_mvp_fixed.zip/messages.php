<?php
require_once __DIR__ . '/api/auth.php';
require_once __DIR__ . '/api/db.php';
require_login();
$u = current_user();
$booking_id = (int)($_GET['booking_id'] ?? 0);

$stmt = db()->prepare("SELECT * FROM bookings WHERE id=? AND (client_id=? OR hairdresser_id=?)");
$stmt->bind_param("iii",$booking_id,$u['id'],$u['id']);
$stmt->execute();
$b = $stmt->get_result()->fetch_assoc();
if(!$b){ http_response_code(404); exit('NOT_FOUND'); }

$other_id = ($u['id']==$b['client_id']) ? $b['hairdresser_id'] : $b['client_id'];
$ou = db()->prepare("SELECT name FROM users WHERE id=?");
$ou->bind_param("i",$other_id);
$ou->execute();
$other = $ou->get_result()->fetch_assoc();
?>
<!doctype html>
<html lang="it">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Chat — HairShake</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
<nav>
  <a href="dashboard.php">Dashboard</a>
  <a href="/api/logout.php">Logout</a>
</nav>

<h1>Chat</h1>
<div class="card">
  <small>Prenotazione #<?php echo (int)$booking_id; ?> • con <?php echo htmlspecialchars($other['name']); ?></small>
</div>

<div class="card">
<?php
$m = db()->prepare("SELECT body,created_at,sender_id FROM messages WHERE booking_id=? ORDER BY created_at ASC LIMIT 200");
$m->bind_param("i",$booking_id);
$m->execute();
$r = $m->get_result();
while($row=$r->fetch_assoc()){
  $me = ((int)$row['sender_id']===$u['id']);
  echo "<div style='text-align:".($me?'right':'left')."'><small>".htmlspecialchars($row['created_at'])."</small><br>".htmlspecialchars($row['body'])."</div><hr>";
}
?>
</div>

<form class="card" action="/api/message_send.php" method="POST">
  <input type="hidden" name="booking_id" value="<?php echo (int)$booking_id; ?>">
  <textarea name="body" rows="3" required placeholder="Scrivi..."></textarea>
  <button style="margin-top:10px">Invia</button>
</form>
</body>
</html>
