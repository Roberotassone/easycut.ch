<?php
require_once __DIR__ . '/api/auth.php';
require_once __DIR__ . '/api/db.php';
require_login();
$service_id = (int)($_GET['service_id'] ?? 0);

$stmt = db()->prepare("SELECT s.id,s.title,s.price_chf,s.duration_min,u.id AS hairdresser_id,u.name AS hairdresser_name
                       FROM services s JOIN users u ON u.id=s.hairdresser_id
                       WHERE s.id=? AND s.active=1");
$stmt->bind_param("i",$service_id);
$stmt->execute();
$svc = $stmt->get_result()->fetch_assoc();
if(!$svc){ http_response_code(404); exit('SERVICE_NOT_FOUND'); }
?>
<!doctype html>
<html lang="it">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Prenota — HairShake</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
<nav>
  <a href="index.html">Home</a>
  <a href="dashboard.php">Dashboard</a>
  <a href="/api/logout.php">Logout</a>
</nav>

<h1>Prenota</h1>
<div class="card">
  <b><?php echo htmlspecialchars($svc['title']); ?></b><br>
  <small><?php echo htmlspecialchars($svc['hairdresser_name']); ?> • CHF <?php echo htmlspecialchars($svc['price_chf']); ?> • <?php echo (int)$svc['duration_min']; ?> min</small>
</div>

<form class="card" action="/api/book_create.php" method="POST">
  <input type="hidden" name="service_id" value="<?php echo (int)$svc['id']; ?>">
  <label>Data e ora inizio (YYYY-MM-DD HH:MM)</label>
  <input name="start_at" required placeholder="2026-01-30 14:00">

  <label style="margin-top:10px">Indirizzo (se servizio a domicilio)</label>
  <input name="address_text" placeholder="Via, numero, CAP, città">

  <label style="margin-top:10px">Note</label>
  <textarea name="notes" rows="3"></textarea>

  <button style="margin-top:10px">Crea prenotazione</button>
</form>

<small>Pagamento: dopo creazione prenotazione, vai in Dashboard e clicca “Paga”.</small>
</body>
</html>
